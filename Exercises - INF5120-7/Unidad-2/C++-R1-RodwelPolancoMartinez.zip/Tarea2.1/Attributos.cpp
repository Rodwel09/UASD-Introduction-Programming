#include "Class/Attributos/Person.h"

int main(){
    Person person;
    // Accessing the attributes of the class Person.
    
    std::cout << person.name << std::endl;
    std::cout << person.age << std::endl;
}