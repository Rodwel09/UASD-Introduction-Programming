#include <iostream>

class Person{
    public:
        std::string name = "Rodwel Polanco Martinez";
        std::string age = "21";
};