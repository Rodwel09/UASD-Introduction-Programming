#include "Class/NumPrimClass.h"

int main(){
    NumPrimClass numCousin = NumPrimClass();

    numCousin.printCousinNumber();
}