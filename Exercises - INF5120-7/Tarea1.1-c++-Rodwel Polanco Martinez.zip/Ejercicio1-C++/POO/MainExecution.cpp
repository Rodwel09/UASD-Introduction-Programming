#include "MySaludosClass.h"

int main(){
    Saludos mySaludos;

    mySaludos.IntroduceAllData();

    mySaludos.printName();
    mySaludos.printAge();
    mySaludos.printSex();
    mySaludos.printWeight();
    mySaludos.printCareer();
    mySaludos.printHeight();
    mySaludos.printSalary();
    mySaludos.printAddress();
    mySaludos.printSchoolID();
    mySaludos.printLanguage();
    mySaludos.printSkinColor();
    mySaludos.printCivilStatus();
    mySaludos.printPhoneNumber();
    mySaludos.printTypeOfBlood();
    mySaludos.printNationality();
    mySaludos.printNationalityID();
    mySaludos.printFinantialCategory();
}